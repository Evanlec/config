pyflakes
========

This version of PyFlakes_ has been improved to use Python's newer ``ast``
module, instead of ``compiler``. So code checking happens faster, and will stay
up to date with new language changes.

.. _PyFlakes: http://http://www.divmod.org/trac/wiki/DivmodPyflakes

Installation
------------
(todo)

IDE Integration
---------------

* vim: pyflakes-vim_

.. _pyflakes-vim: http://github.com/kevinw/pyflakes-vim

